# ISKAASHATADA BIN NAAKHUDI

Mobile-first accounting PWA for a cooperative (iskaashato): income and expenses, members grouped by family, Qaaraan/event tracking, dues reminders, role-based access, financial statements, backup and sharing. UI language: Somali. Static site (no build step) + Firebase Auth and Firestore, hosted on GitHub Pages.

## Pages

| Page | URL | Login | Purpose |
|---|---|---|---|
| Landing | `/` | no | Links to the pages below |
| Public | `/dadweyne/` | **no** | View only. Shows the summary the admin chose to publish (optional balance, Qaaraan progress, how to contribute, anonymised feed). `noindex`. |
| Members | `/xubin/` | yes | Work page. What each person can do depends on their role (table below). |
| Admin | `/admin/` | yes, admin only | Approve accounts, assign roles and link them to members, correct/delete entries, manage members and phone numbers, settings, public page, backup/restore, audit log. |

## Roles on the members page

| Capability | viewer | adder | treasurer | admin |
|---|:-:|:-:|:-:|:-:|
| See balance, activity feed, Qaaraan, members, statements, own account | ✓ | ✓ | ✓ | ✓ |
| Add income | | ✓ | ✓ | ✓ |
| Add expenses | | | ✓ | ✓ |
| Add members | | | ✓ | ✓ |
| See phone numbers, dues reminders (call / WhatsApp) | | | ✓ | ✓ |
| Edit or delete entries, manage roles and settings | | | | ✓ (on `/admin/`) |

`pending` accounts (new sign-ups) can see nothing until the admin assigns a role. Every rule above is enforced server-side in `firestore.rules`; the UI only mirrors it. Phone numbers are stored in a separate `contacts` collection that only treasurer/admin can read. The public page reads one `pub/summary` document and nothing else.

## Setup

1. Create a Firebase project. Enable **Authentication > Email/Password** and create a **Firestore** database.
2. Add a Web app and paste its config into `public/assets/js/config.js`.
3. Publish the rules: `firebase deploy --only firestore:rules` (or paste `firestore.rules` into the console).
4. Sign up once on `/xubin/`. In the Firestore console open `users/<your uid>` and set `role` to `admin`. Use `/admin/` from then on.
5. Authentication > Settings > Authorized domains: add `<username>.github.io`. Consider enabling App Check and restricting the API key to your domain.

## Deploy to GitHub Pages

Push to `main`, then Settings > Pages > Source: **GitHub Actions**. The workflow in `.github/workflows/pages.yml` publishes `public/`.

## Local development

```
cd public && python3 -m http.server 8080
```

## Layout

```
public/              static site: landing, xubin/, dadweyne/, admin/, assets, manifest, service worker
firestore.rules      security rules
firebase.json        Firebase CLI config
.github/workflows    GitHub Pages deployment
```

## Backups

Admin > Kaydin: download JSON (includes phone numbers; keep it private) or CSV, and restore from the same page.

License: MIT
